from setuptools import setup

setup(name='psd-parvaresh',
      version='0.3',
      description='PSD Calculator of Pupil Metrics',
      packages=['psd-maker'],
      author='Stephen Parvaresh',
      zip_safe=False)