# PowerSpectralDensity
Calculate PSD from a specified signal and return new DataFrame

# Installation
There should be no necessary libraries to run the code here beyond the Anaconda distribution of Python. The code should run with no issues using Python versions 3.*.

# Project Motivation
For this project, I wanted to create object-oriented code that would calculate Power Spectral Density.

# File Descriptions
There is 1 python file available here. Markdown cells were used to assist in walking through the thought process for individual steps.
